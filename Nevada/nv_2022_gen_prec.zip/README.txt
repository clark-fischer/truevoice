Nevada 2022 General Election Precinct-Level Results

## RDH Date Retrieval
04/03/23

## Sources
[Nevada Secretary of State](https://www.nvsos.gov/sos/elections/election-information/precinct-level-results)

## Notes on Field Names (adapted from VEST):
Columns reporting votes generally follow the pattern: 
One example is:
G16PREDCLI
The first character is G for a general election, P for a primary, S for a special, and R for a runoff.
Characters 2 and 3 are the year of the election.*
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.

*To fit within the GIS 10 character limit for field names, the naming convention is slightly different for the State Legislature and US House of Representatives. All fields are listed below with definitions.

Office Codes Used:
ATG - Attorney General
CAJ# - Court of Appeals Judge Department #
CNT - State Controller
CON## - U.S. Congress District ##
GOV - Governor and Lieutenant Governor
LTG - Lieutenant Governor
SCJX - Supreme Court Justice Seat X
SL###  - State Legislative Lower District ###
SOS - Secretary of State
SQ# - State Question #
SU##  - State Legislative Upper District ##
TRE - State Treasurer
USS - U.S. Senate

Party Codes Used:
A - Independent American Party
D - Democratic
I - Independent / No Party Preference
L - Libertarian
N - Non-Partisan Election
O - Other / Write In Votes
R - Republican

Note: Nevada does not provide party information for candidates in its precinct-level results. Candidate information is pulled from this page on the Nevada Secretary of State website (https://silverstateelection.nv.gov/).

## Fields:
Field Name Description 
UNIQUE_ID  Unique ID for each precinct                                            
COUNTYFP   County FIP identifier                                                  
CNTY_NAME  County Name                                                            
PREC       Precinct Identifier                                                            
G22ATGDFOR Attorney General: Ford, Aaron D.                                       
G22ATGOWRI Attorney General: None Of These Candidates                             
G22ATGRCHA Attorney General: Chattah, Sigal                                       
G22CNTDSPI State Controller: Spiegel, Ellen                                       
G22CNTLPRO State Controller: Profeta, Jed W.                                      
G22CNTOWRI State Controller: None Of These Candidates                             
G22CNTRMAT State Controller: Matthews, Andy                                       
G22GOVABRI Governor: Bridges, Ed                                                  
G22GOVDSIS Governor: SISOLAK, Steve                                               
G22GOVLDAV Governor: Davis, Brandon                                               
G22GOVOWRI Governor: None Of These Candidates                                     
G22GOVRLOM Governor: Lombardo, Joe                                                
G22LTGAHOG Lieutenant Governor: Hoge, William                                     
G22LTGDCAN Lieutenant Governor: Cano Burkhead, Elizabeth "Lisa"                   
G22LTGIDEL Lieutenant Governor: Delap, John "Trey"                                
G22LTGLTAC Lieutenant Governor: Tachiquin, Javi "Trujillo"                        
G22LTGOWRI Lieutenant Governor: None Of These Candidates                          
G22LTGRANT Lieutenant Governor: Anthony, Stavros                                  
G22SOSAHAN Secretary of State: Hansen, Janine                                     
G22SOSDAGU Secretary of State: Aguilar, Francisco "Cisco"                         
G22SOSLCRA Secretary of State: Crane, Ross                                        
G22SOSOWRI Secretary of State: None Of These Candidates                           
G22SOSRMAR Secretary of State: Marchant, Jim                                      
G22SQ1NO   STATE QUESTION NO. 1 - EQUAL RIGHTS AMENDMENT: No                      
G22SQ1YES  STATE QUESTION NO. 1 - EQUAL RIGHTS AMENDMENT: Yes                     
G22SQ2NO   STATE QUESTION NO. 2 - MINIMUM WAGE AMENDMENT: No                      
G22SQ2YES  STATE QUESTION NO. 2 - MINIMUM WAGE AMENDMENT: Yes                     
G22SQ3NO   STATE QUESTION NO. 3 - TOP FIVE RANKED CHOICE VOTING INITIATIVE: No    
G22SQ3YES  STATE QUESTION NO. 3 - TOP FIVE RANKED CHOICE VOTING INITIATIVE: Yes   
G22TREAHEN State Treasurer: Hendrickson, Margaret                                 
G22TREDCON State Treasurer: Conine, Zach                                          
G22TRELELL State Treasurer: Elliott, Bryan                                        
G22TREOWRI State Treasurer: None Of These Candidates                              
G22TRERFIO State Treasurer: Fiore, Michele                                        
G22USSARUB United States Senator: RUBINSON, BARRY                                 
G22USSDCOR United States Senator: Cortez Masto, Catherine                         
G22USSILIN United States Senator: Lindemann, Barry                                
G22USSLSCO United States Senator: Scott, Neil                                     
G22USSOWRI United States Senator: None Of These Candidates                        
G22USSRLAX United States Senator: Laxalt, Adam Paul                               
GCAJ1NFOR  Court of Appeals Judge, Department 1: Forsberg, Rhonda K.              
GCAJ1NWES  Court of Appeals Judge, Department 1: Westbrook, Deborah               
GCAJ1NWRI  Court of Appeals Judge, Department 1: None Of These Candidates         
GCAJ2NGIB  Court of Appeals Judge, Department 2: Gibbons, Michael                 
GCAJ2NWRI  Court of Appeals Judge, Department 2: None Of These Candidates         
GCAJ3NBUL  Court of Appeals Judge, Department 3: Bulla, Bonnie                    
GCAJ3NWRI  Court of Appeals Judge, Department 3: None Of These Candidates         
GCON01DTIT U.S. Representative in Congress, District 1: Titus, Dina               
GCON01LCAV U.S. Representative in Congress, District 1: Cavanaugh, Ken            
GCON01RROB U.S. Representative in Congress, District 1: Robertson, Mark           
GCON02ABES U.S. Representative in Congress, District 2: Best, Russell             
GCON02DKRA U.S. Representative in Congress, District 2: Krause, Elizabeth Mercedes
GCON02LBAB U.S. Representative in Congress, District 2: Baber, Darryl             
GCON02RAMO U.S. Representative in Congress, District 2: Amodei, Mark E.           
GCON03DLEE U.S. Representative in Congress, District 3: Lee, Susie                
GCON03RBEC U.S. Representative in Congress, District 3: Becker, April             
GCON04DHOR U.S. Representative in Congress, District 4: Horsford, Steven A.       
GCON04RPET U.S. Representative in Congress, District 4: Peters, Sam               
GSCJANBEL  Supreme Court Justice, Seat A: Bell, Linda                             
GSCJANWRI  Supreme Court Justice, Seat A: None Of These Candidates                
GSCJENPAR  Supreme Court Justice, Seat E: Parraguirre, Ron D.                     
GSCJENWRI  Supreme Court Justice, Seat E: None Of These Candidates                
GSL001DMON State Assembly, District  1: Monroe-Moreno, Daniele                    
GSL001IMCA State Assembly, District  1: McAtee-MacRae, Patrick "Mac"              
GSL001RBRI State Assembly, District  1: Brinkley, Garland Lee                     
GSL002DCHR State Assembly, District  2: Christenson, Nick                         
GSL002LBED State Assembly, District  2: Bednarz, Jason                            
GSL002RKAS State Assembly, District  2: Kasama, Heidi                             
GSL003DTOR State Assembly, District  3: Torres, Selena Elizabeth                  
GSL003RLEM State Assembly, District  3: Lemack, Joshua                            
GSL004LBUR State Assembly, District  4: Burns, Darby Lee                          
GSL004RMCA State Assembly, District  4: McArthur, Richard                         
GSL005DMIL State Assembly, District  5: Miller, Brittney                          
GSL005LMOR State Assembly, District  5: Morgan, Ronald                            
GSL005RQUI State Assembly, District  5: Quinn, Kelly                              
GSL006DSUM State Assembly, District  6: Summers-Armstrong, Shondra                
GSL006RRIO State Assembly, District  6: Rios, Kathryn "Kat"                       
GSL007DMIL State Assembly, District  7: Miller, Cameron Homer "C.H."              
GSL007RPAL State Assembly, District  7: Palmer, Anthony "Tony"                    
GSL008DNGU State Assembly, District  8: Nguyen, Duy                               
GSL008RLOG State Assembly, District  8: Logan, Jenann                             
GSL009DYEA State Assembly, District  9: Yeager, Steve                             
GSL009RFLE State Assembly, District  9: Fleming, Ryan Patrick                     
GSL010DNGU State Assembly, District 10: Nguyen, Rochelle                          
GSL010RHER State Assembly, District 10: Hernandez, Sandie "Gisela"                
GSL011DDUR State Assembly, District 11: Duran, Beatrice "Bea"                     
GSL011RKRA State Assembly, District 11: Krattiger, Eric                           
GSL012DCAR State Assembly, District 12: Carter, II, Max E.                        
GSL012RLAR State Assembly, District 12: Larsen, Flemming                          
GSL013DRUC State Assembly, District 13: Rucker, Will                              
GSL013RHIB State Assembly, District 13: Hibbetts, Brian                           
GSL014DMOS State Assembly, District 14: Mosca, Erica                              
GSL014RSTA State Assembly, District 14: Stamper, Shawn                            
GSL015DWAT State Assembly, District 15: Watts, Howard                             
GSL015RBAN State Assembly, District 15: Bang, Steven D.                           
GSL016DGON State Assembly, District 16: Gonzalez, Cecelia                         
GSL016RHOL State Assembly, District 16: Holder, Jesse "Jake"                      
GSL017DTHO State Assembly, District 17: Thomas, Clara "Claire"                    
GSL017RPAW State Assembly, District 17: Pawley, III, Eugene Michael               
GSL018DCON State Assembly, District 18: Considine, Venicia                        
GSL018RDEC State Assembly, District 18: DeCorte, Christine                        
GSL019RYUR State Assembly, District 19: Yurek, Thaddeus "Toby"                    
GSL020DORE State Assembly, District 20: Orentlicher, David                        
GSL020LLAR State Assembly, District 20: LaRow, Josiah L.                          
GSL020RVAU State Assembly, District 20: Vaughan, Stan                             
GSL021DMAR State Assembly, District 21: Marzola, Elaine                           
GSL021RPET State Assembly, District 21: Petrick, Jon S.                           
GSL022DRAM State Assembly, District 22: Ramos, Rick                               
GSL022RHAR State Assembly, District 22: Hardy, Melissa                            
GSL023DBRI State Assembly, District 23: Brickfield, Elizabeth                     
GSL023LMAN State Assembly, District 23: Manley, Mercy                             
GSL023RGAL State Assembly, District 23: Gallant, Danielle                         
GSL024DPET State Assembly, District 24: Peters, Sarah                             
GSL024RKIN State Assembly, District 24: King, Dorzell                             
GSL025DLAR State Assembly, District 25: La Rue Hatch, Selena                      
GSL025RKUM State Assembly, District 25: Kumar, Sam                                
GSL026LMIT State Assembly, District 26: Mitchell, Reed                            
GSL026RDEL State Assembly, District 26: Delong, Rich                              
GSL027DTAY State Assembly, District 27: Taylor, Angela                            
GSL027RORT State Assembly, District 27: Ortiz, Carmen L.                          
GSL028DDSI State Assembly, District 28: D'Silva, Reuben                           
GSL028RBRO State Assembly, District 28: Brown, Clint                              
GSL029DCOH State Assembly, District 29: Cohen, Lesley Elizabeth                   
GSL029RKNI State Assembly, District 29: Knightly, Rhonda                          
GSL030DAND State Assembly, District 30: Anderson, Natha C.                        
GSL030LMCG State Assembly, District 30: McGeein, Garrett                          
GSL030RROD State Assembly, District 30: RODRIGUEZ-ELKINS, RICCI                   
GSL031RDIC State Assembly, District 31: Dickman, Jill                             
GSL032RHAN State Assembly, District 32: Hansen, Alexis M.                         
GSL033DGAR State Assembly, District 33: Garrard, John "Doc"                       
GSL033RGUR State Assembly, District 33: Gurr, Bert                                
GSL034DBIL State Assembly, District 34: Bilbray-Axelrod, Shannon                  
GSL034RBUT State Assembly, District 34: Butler, Stacy                             
GSL035DGOR State Assembly, District 35: Gorelow, Michelle                         
GSL035LROB State Assembly, District 35: Robinson, Mindy                           
GSL035RJON State Assembly, District 35: Jones, Tiffany                            
GSL036RHAF State Assembly, District 36: Hafen, II, Gregory T.                     
GSL037DBAC State Assembly, District 37: Backus, Shea                              
GSL037LTED State Assembly, District 37: Tedoff, Marc                              
GSL037RDEA State Assembly, District 37: Deaville, Jacob                           
GSL038RKOE State Assembly, District 38: Koenig, Gregory S.                        
GSL039DNOB State Assembly, District 39: Noble, Janice E.                          
GSL039RGRA State Assembly, District 39: Gray, Ken                                 
GSL040DMCD State Assembly, District 40: McDaniel, Shannon C.                      
GSL040LTOL State Assembly, District 40: Toll, Sam                                 
GSL040RONE State Assembly, District 40: O'Neill, Philip "PK"                      
GSL041DJAU State Assembly, District 41: Jauregui, Sandra                          
GSL041LMCN State Assembly, District 41: McNamara, Sean                            
GSL041RBOD State Assembly, District 41: Bodine, Paul                              
GSL042DBRO State Assembly, District 42: Brown-May, Tracy                          
GSL042RFAC State Assembly, District 42: Facey, Edward "Eddie"                     
GSU02DFLO  State Senate, District 2: Flores, Edgar                                
GSU02RHEN  State Senate, District 2: Henderson, Leo                               
GSU08DLOO  State Senate, District 8: Loop, Marilyn Dondero                        
GSU08RPAU  State Senate, District 8: Paulos, Joey                                 
GSU09DSCH  State Senate, District 9: Scheible, Melanie                            
GSU09RBRO  State Senate, District 9: Brown, Tina                                  
GSU10DDON  State Senate, District 10: DONATE, FABIAN                              
GSU10LCUN  State Senate, District 10: Cunningham, Chris                           
GSU10RGRA  State Senate, District 10: Graviet, Philip                             
GSU12DPAZ  State Senate, District 12: Pazina, Julie Ann                           
GSU12RARR  State Senate, District 12: Arrington, Cherlyn                          
GSU13DDAL  State Senate, District 13: Daly, Richard "Skip"                        
GSU13RBUE  State Senate, District 13: Buehler, Matthew R.                         
GSU14RHAN  State Senate, District 14: Hansen, Ira                                 
GSU16DSIM  State Senate, District 16: Sims, Aaron                                 
GSU16RKRA  State Senate, District 16: Krasner, Lisa                               
GSU17RTIT  State Senate, District 17: Titus, Robin L.                             
GSU20DFOU  State Senate, District 20: Foutz, Brent                                
GSU20LMIL  State Senate, District 20: Mills, Brandon                              
GSU20RSTO  State Senate, District 20: Stone, Jeff                                 
GSU21DOHR  State Senate, District 21: Ohrenschall, James                          
GSU21RLAR  State Senate, District 21: Larsen, April                               
                                                   
## Processing Steps
Visit the RDH GitHub and the processing script for this code [here](https://github.com/nonpartisan-redistricting-datahub/pber_collection)

## Additional Notes
As noted in the precinct-level file, Nevada puts an "*" in a handful of vote fields when there was low voter turnout to protect voter privacy. These "missing" votes were re-allocated back to the file as part of our processing.

First we transcribed the certified county-level vote totals from the[2022 Official General Election Abstract of Votes](https://www.nvsos.gov/sos/elections/election-information/2022-election-information/-fsiteid-1) and then calculated the number of votes there were not present in each county in each race. These votes were then distributed proportionally across all precincts that contained an "*" for that particular race. A handful of precincts contained actual votes in some races and an asterisk in other races, but the actual vote information was not used at all in the distribution of votes. Please note that this method assumes the accuracy of the votes in the precinct-level file.

The official abstract of votes appears to contain a typo for GSU14RHAN in Lander county, and as such this is the only county and race where the totals of this precinct-level file do not match those of the official totals. In this instance, there are fewer votes in the official abstract total, than present in the precinct-level file. There were no precincts with asterisks for this race and furthermore equating this totals would require subtracting votes. The abstract also has a typo listed for the total votes for GCAJ1NFOR, in which the total votes listed do not match the sum of the total votes across all of the counties. The sum of the total votes across the counties, which matches other information on the Nevada website, is used in this case.

Please direct questions related to processing this dataset to info@redistrictingdatahub.org.
